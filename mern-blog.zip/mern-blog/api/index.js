// Core dependencies
const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const cookieParser = require("cookie-parser");
const multer = require("multer");
const fs = require("fs");

// Models
const User = require("./models/User");
const Post = require("./models/Post");

const app = express();

// Middleware setup for handling file uploads (storing in 'uploads/' folder)
const uploadMiddleware = multer({ dest: "uploads/" });

// Hashing salt and JWT secret key
const salt = bcrypt.genSaltSync(10);
const secret = "asdfe45we45w345wegw345werjktjwertkj";

// Middlewares for parsing JSON, cookies, handling CORS, and serving uploaded images
app.use(cors({ credentials: true, origin: "http://localhost:3000" }));
app.use(express.json());
app.use(cookieParser());
app.use("/uploads", express.static(__dirname + "/uploads"));

// MongoDB connection
mongoose
  .connect("mongodb://localhost:27017/blog")
  .then(() => console.log("db connected"))
  .catch(() => console.log("db not connected"));

/**
 * Route: POST /register
 * Registers a new user with a hashed password
 */
app.post("/register", async (req, res) => {
  const { username, password } = req.body;
  try {
    const userDoc = await User.create({
      username,
      password: bcrypt.hashSync(password, salt),
    });
    res.json(userDoc);
  } catch (e) {
    console.log(e);
    res.status(400).json(e);
  }
});

/**
 * Route: POST /login
 * Authenticates the user and sends JWT in a cookie
 */
app.post("/login", async (req, res) => {
  const { username, password } = req.body;
  const userDoc = await User.findOne({ username });

  const passOk = bcrypt.compareSync(password, userDoc.password);
  if (passOk) {
    // On success, issue JWT token
    jwt.sign({ username, id: userDoc._id }, secret, {}, (err, token) => {
      if (err) throw err;
      res.cookie("token", token).json({
        id: userDoc._id,
        username,
      });
    });
  } else {
    res.status(400).json("wrong credentials");
  }
});

/**
 * Route: GET /profile
 * Verifies token and returns current logged-in user's info
 */
app.get("/profile", (req, res) => {
  const { token } = req.cookies;
  jwt.verify(token, secret, {}, (err, info) => {
    if (err) throw err;
    res.json(info);
  });
});

/**
 * Route: POST /logout
 * Clears the auth cookie
 */
app.post("/logout", (req, res) => {
  res.cookie("token", "").json("ok");
});

/**
 * Route: POST /post
 * Creates a new blog post with uploaded image and authenticated author
 */
app.post("/post", uploadMiddleware.single("file"), async (req, res) => {
  // Rename uploaded file with original extension
  const { originalname, path } = req.file;
  const parts = originalname.split(".");
  const ext = parts[parts.length - 1];
  const newPath = path + "." + ext;
  fs.renameSync(path, newPath);

  // Verify user from JWT before saving post
  const { token } = req.cookies;
  jwt.verify(token, secret, {}, async (err, info) => {
    if (err) throw err;
    const { title, summary, content } = req.body;
    const postDoc = await Post.create({
      title,
      summary,
      content,
      cover: newPath,
      author: info.id,
    });
    res.json(postDoc);
  });
});

/**
 * Route: PUT /post
 * Updates an existing post if the logged-in user is the author
 */
app.put("/post", uploadMiddleware.single("file"), async (req, res) => {
  let newPath = null;

  // Handle new image upload (if any)
  if (req.file) {
    const { originalname, path } = req.file;
    const parts = originalname.split(".");
    const ext = parts[parts.length - 1];
    newPath = path + "." + ext;
    fs.renameSync(path, newPath);
  }

  const { token } = req.cookies;
  jwt.verify(token, secret, {}, async (err, info) => {
    if (err) throw err;
    const { id, title, summary, content } = req.body;

    const postDoc = await Post.findById(id);

    // Only allow author to update
    const isAuthor = JSON.stringify(postDoc.author) === JSON.stringify(info.id);
    if (!isAuthor) {
      return res.status(400).json("you are not the author");
    }

    // Update post data
    await postDoc.updateOne({
      title,
      summary,
      content,
      cover: newPath ? newPath : postDoc.cover,
    });

    res.json(postDoc);
  });
});

/**
 * Route: GET /post
 * Fetches recent 20 posts, sorted by creation date, with author info populated
 */
app.get("/post", async (req, res) => {
  res.json(
    await Post.find()
      .populate("author", ["username"])
      .sort({ createdAt: -1 })
      .limit(20)
  );
});

/**
 * Route: GET /post/:id
 * Returns a single post by ID, including author info
 */
app.get("/post/:id", async (req, res) => {
  const { id } = req.params;
  const postDoc = await Post.findById(id).populate("author", ["username"]);
  res.json(postDoc);
});

/**
 * Start the server
 */
app.listen(4000, function () {
  console.log("server is listening at the port 4000");
});
